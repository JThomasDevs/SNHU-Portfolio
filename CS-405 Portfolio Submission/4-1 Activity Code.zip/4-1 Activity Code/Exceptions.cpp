// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
// Include the exception CPP library
#include <exception>

/* Custom Exception Class */
class jons_exception : public std::exception {
public:
    const char* what() const throw() {
        return "Jon's Custom Exception was caught";
    }
} jonex;

bool do_even_more_custom_application_logic()
{
    // Throw a basic exception
    throw std::exception("This is the standard exception");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}
void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;
    try {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (std::exception& e) { // Catch standard exception
		std::cout << "Exception Caught: " << e.what() << std::endl;
	}

    throw jonex; // throw custom exception
    
    // Because the function exits when the above exception is thrown,
    // the below statement is never printed to console.
    // A similar thing happens in the do_even_more_custom_application_logic() function
    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    if (den == 0) {
        // Logic error is the best fit I found for divide by zero in the C++ <exception> docs
        throw std::logic_error("Division by zero error");
    }
    return (num / den);
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0;
    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (std::logic_error& e) { // Catch ONLY the exception thrown by divide()
		std::cout << "Division Exception Caught: " << e.what() << std::endl;
	}
}

int main()
{
    try {
        std::cout << "Exceptions Tests!" << std::endl;

        do_division();
        do_custom_application_logic();
    }
    catch (jons_exception& e) { // Catch custom error
		std::cout << "Custom Exception Caught: " << e.what() << std::endl;
	}
	catch (std::exception& e) { // Catch standard exception
		std::cout << "Exception Caught: " << e.what() << std::endl;
	}
	catch (...) { // Catch all other exceptions
		std::cout << "An uncaught exception was thrown." << std::endl;
	}
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
