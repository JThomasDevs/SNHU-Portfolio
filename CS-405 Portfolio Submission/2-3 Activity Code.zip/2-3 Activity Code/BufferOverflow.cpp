// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  const std::string account_number = "CharlieBrown42";
  char user_input[20];
  std::cout << "Enter a value: ";
  /* cin.get() reads a maximum of 19 characters from the input buffer, setting the 20th byte to a null byte -> '\0'
   * to indicate the end of the string array. 
   * This method prevents immediate overflow and stack corruption from trying to place more bytes into user_input than it can hold
   * but there must still be a check if overflow would have occurred without this method. */
  std::cin.get(user_input, 20);

  // Conditional check to prevent buffer overflow
  /* cin.peek() reads the next character in the input buffer.
   * In all cases EXCEPT overflow, the next character in buffer after using cin.get() will be a newline character -> '\n'
   * This is because this character is placed into the buffer when the user presses ENTER to submit input.
   * However, if the input would have caused overflow without the .get() method (more than 20 characters were entered),
   * then .peek() will read the 20th byte in the buffer (Note that this is the 20th byte in the buffer BEFORE being truncated by .get())
   * which will NOT be '\n' because the ENTER key will have been pressed some time AFTER the 20th byte was entered. */
  if (std::cin.peek() != '\n') {
	// When the conditional is true, we just print an error message to console and exit with Code 1.
	std::cout << "Invalid input. Please enter a value less than 20 characters." << std::endl;
	return 1;
  }

  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
