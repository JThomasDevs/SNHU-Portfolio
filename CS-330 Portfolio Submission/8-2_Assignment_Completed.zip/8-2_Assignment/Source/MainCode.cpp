#include <GLFW\glfw3.h>
#include "linmath.h"
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <iostream>
#include <vector>
#include <windows.h>
#include <time.h>

using namespace std;

const float DEG2RAD = 3.14159 / 180;
const float M_PI = 3.141592653589;

void processInput(GLFWwindow* window);
void mouse_button_callback(GLFWwindow* window, int button, int action, int mods);
int GetRandomDirection();

enum BRICKTYPE { REFLECTIVE, DESTRUCTABLE };
enum ONOFF { ON, OFF };
enum BRICKCOLOR { RED, GREEN, BLUE }; // enum used to rotate brick colors

class Brick
{
public:
	float red, green, blue;
	float x, y, width;
	BRICKTYPE brick_type;
	BRICKCOLOR brick_color;
	ONOFF onoff;

	Brick(BRICKTYPE bt, float xx, float yy, float ww, float rr, float gg, float bb)
	{
		brick_type = bt; x = xx; y = yy, width = ww; red = rr, green = gg, blue = bb;
		onoff = ON, brick_color = RED;
	};

	void drawBrick()
	{
		if (onoff == ON)
		{
			double halfside = width / 2;

			glColor3d(red, green, blue);
			glBegin(GL_POLYGON);

			glVertex2d(x + halfside, y + halfside);
			glVertex2d(x + halfside, y - halfside);
			glVertex2d(x - halfside, y - halfside);
			glVertex2d(x - halfside, y + halfside);

			glEnd();
		}
	}
};

class Circle
{
public:
	float red, green, blue;
	float radius;
	float x;
	float y;
	float speed = 0.03;
	int direction;

	Circle(double xx, double yy, double rr, int dir, float rad, float r, float g, float b)
	{
		x = xx;
		y = yy;
		radius = rr;
		red = r;
		green = g;
		blue = b;
		radius = rad;
		direction = dir;
	}

	void CheckCollision(Brick* brk) {
		//             left side			   right side                      top side                    bottom side
		if ((x > brk->x - brk->width && x <= brk->x + brk->width) && (y > brk->y - brk->width && y <= brk->y + brk->width)) {
			if (brk->brick_type == REFLECTIVE) {
				// Determine which side of the brick the ball hit
				float dx = x - brk->x;
				float dy = y - brk->y; // Distance from the center of the brick to the center of the ball

				// If dx is greater than dy, the ball hit the left or right of the brick
				if (abs(dx) > abs(dy)) {
					// Reflect off the left or right of the brick
					direction = M_PI - direction;
					// Rebound step to prevent the ball from getting stuck in the wall
					// If the centerpoint of is within the brick, move the ball outside the brick
					x = (dx > 0) ? brk->x + brk->width : brk->x - brk->width;
				} else {
					// Reflect off the top or bottom of the brick
					direction = 2 * M_PI - direction;
					// Rebound step
					y = (dy > 0) ? brk->y + brk->width : brk->y - brk->width;
				}

				x += speed * cos(direction);
				y += speed * sin(direction);
				switch (brk->brick_color) {
					case RED:
						brk->brick_color = GREEN;
						brk->red = 0;
						brk->green = 1;
						break;
					case GREEN:
						brk->brick_color = BLUE;
						brk->green = 0;
						brk->blue = 1;
						break;
					case BLUE:
						brk->brick_color = RED;
						brk->blue = 0;
						brk->red = 1;
						break;
					default:
						break;
				}
			} else if (brk->brick_type == DESTRUCTABLE) {
				// Turn destructable brick off when we hit it with a Circle
				brk->onoff = OFF;
			}
		}
	}

	void MoveOneStep() {
		// Move the circle
		x += speed * cos(direction); // x direction of ball at this instant
		y += speed * sin(direction); // y direction of ball at this instant
		// cos and sin are used to calculate the x and y components of the ball's direction vector

		// Check for collision with the window edges and reflect if necessary
		if (x < -1 + radius) {
			// Reflect off the left window edge by inverting the x-direction
			direction = M_PI - direction-0.1;
			// Rebound step to prevent the ball from getting stuck in the wall
			x = -1 + radius;
		} else if (x > 1 - radius) {
			// Reflect off the right window edge by inverting the x-direction
			direction = M_PI - direction-0.1;
			// Rebound step
			x = 1 - radius;
		}

		if (y < -1 + radius) {
			// Reflect off the bottom window edge by inverting the y-direction
			direction = 2 * M_PI - direction-0.1;
			// Rebound step
			y = -1 + radius;
		}
		else if (y > 1 - radius) {
			// Reflect off the top window edge by inverting the y-direction
			direction = 2 * M_PI - direction-0.1;
			// Rebound step
			y = 1 - radius;
		}
		/* A brief aside - Reflection Math: 
		 * 
		 * Because our 'direction' parameter is just the angle in radians of the ball's path, and we know from mathematical
		 * principles that the reflection angle of an object against a surface is the supplement of the angle of incidence (the 
		 * angle at which the line intersects the surface). With the angle stored in 'direction' being measured with 0 set to 
		 * the positive x direction - meaning that PI (180deg) is the negative x direction. Therefore, to mimic the effect of 
		 * an object being reflected against a flat surface, we can simply mirror the direction across the x-axis. This is done, 
		 * as seen above, by subtracting the angle of incidence (direction) from PI. 
		 * Ex. PI - (PI/4) = (3*PI/4) */
	}

	void DrawCircle()
	{
		glColor3f(red, green, blue);
		glBegin(GL_POLYGON);
		for (int i = 0; i < 360; i++) {
			float degInRad = i * DEG2RAD;
			glVertex2f((cos(degInRad) * radius) + x, (sin(degInRad) * radius) + y);
		}
		glEnd();
	}
};

vector<Circle> world;
vector<Brick> bricks; // global vector to track Brick objects - used for ball spawn collision detection

int main(void) {
	srand(time(NULL));

	if (!glfwInit()) {
		exit(EXIT_FAILURE);
	}
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 2);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);
	GLFWwindow* window = glfwCreateWindow(480, 480, "Click Anywhere to Begin!", NULL, NULL);
	if (!window) {
		glfwTerminate();
		exit(EXIT_FAILURE);
	}
	glfwMakeContextCurrent(window);
	glfwSwapInterval(1);

	// Brick(TYPE, x, y, width, r, g, b)
	// Reflective Pentagram
	Brick brick(REFLECTIVE, 0.0, 0.6, 0.2, 1, 0, 0);
	bricks.push_back(brick);
	Brick brick2(REFLECTIVE, 0.6, 0.1, 0.2, 1, 0, 0);
	bricks.push_back(brick2);
	Brick brick3(REFLECTIVE, 0.4, -0.6, 0.2, 1, 0, 0);
	bricks.push_back(brick3);
	Brick brick4(REFLECTIVE, -0.4, -0.6, 0.2, 1, 0, 0);
	bricks.push_back(brick4);
	Brick brick5(REFLECTIVE, -0.6, 0.1, 0.2, 1, 0, 0);
	bricks.push_back(brick5);

	// Destructable Pentagram
	Brick brick6(DESTRUCTABLE, 0.0, -0.6, 0.2, 0, 1, 0);
	bricks.push_back(brick6);
	Brick brick7(DESTRUCTABLE, -0.6, -0.1, 0.2, 0, 1, 0);
	bricks.push_back(brick7);
	Brick brick8(DESTRUCTABLE, -0.4, 0.6, 0.2, 0, 1, 0);
	bricks.push_back(brick8);
	Brick brick9(DESTRUCTABLE, 0.4, 0.6, 0.2, 0, 1, 0);
	bricks.push_back(brick9);
	Brick brick10(DESTRUCTABLE, 0.6, -0.1, 0.2, 0, 1, 0);
	bricks.push_back(brick10);

	// Set mouse callback function here
	glfwSetMouseButtonCallback(window, mouse_button_callback);

	while (!glfwWindowShouldClose(window)) {
		//Setup View
		float ratio;
		int width, height;
		glfwGetFramebufferSize(window, &width, &height);
		ratio = width / (float)height;
		// Adjust the viewport to maintain aspect ratio when width > height
		if (width > height) {
			glViewport(width/height, 0, height, height);
			// This will cause empty space on the side of the Viewport BUT
			// will maintain the aspect ratio of the objects
		} else if (height > width) {
			glViewport(0, height/width, width, width);
		} else {
			glViewport(0, 0, width, height);
		}
		glClear(GL_COLOR_BUFFER_BIT);

		processInput(window);

		//Movement
		for (int i = 0; i < world.size(); i++)
		{
			for (Brick& brick : bricks) {
				if (brick.onoff == ON) { // Only check collisions against bricks that are currently active
					world[i].CheckCollision(&brick);
				}
			} // Check collision of every ball against every brick
			world[i].MoveOneStep();
			world[i].DrawCircle();
		}

		for (Brick& brick : bricks) { // Draw every brick that is ON
			if (brick.onoff == ON) {
				brick.drawBrick();
			}
		}

		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	glfwDestroyWindow(window);
	glfwTerminate;
	exit(EXIT_SUCCESS);
}


void processInput(GLFWwindow* window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);

	// Removed SPACE Keybind
}

void mouse_button_callback(GLFWwindow* window, int button, int action, int mods) {
	// Spawn a random color ball traveling in a random direction at the click location
	if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS) {
		double xpos, ypos;
		//getting cursor position
		glfwGetCursorPos(window, &xpos, &ypos);
		int width, height;
		glfwGetWindowSize(window, &width, &height); // get window size
		// convert screen coordinates to GL coordinates
		float x = (xpos / width) * 2 - 1;
		float y = 1 - (ypos / height) * 2; // Invert y axis

		// ball radius - to be used in collision detection
		float radius = 0.02f;
		float offset = radius + 0.005f;

		// If we clicked to spawn the ball inside a Brick's area, spawn the ball outside of the Brick's area
		for (Brick& brick : bricks) {
			/* Each Brick has its origin point in the middle of the shape. 
			 * Because of this, we need to use HALF the width and height when checking 
			 * collision boundaries. */
			// If we clicked inside a Brick
			if ((x > brick.x - brick.width-offset && x < brick.x + brick.width+offset) && (y > brick.y - brick.width-offset && y < brick.y + brick.width+offset)) {
				float dx = x - brick.x;
				float dy = y - brick.y; // find the difference between the click location and brick center
				/* Depending on which is greater, move the ball in the x or y direction to move
				 * it outside the Brick */
				if (abs(dx) > abs(dy)) {
					// Move in the x direction
					x = (dx > 0) ? brick.x + brick.width+offset : brick.x - brick.width-offset;
					/* The above expression checks if we are closer to the left or right side of 
					 * the Brick. */
				}
				else {
					//Move in the y direction
					y = (dy > 0) ? brick.y + brick.width+offset : brick.y - brick.width-offset;
					/* Similarly, this expression checks if we are closer to the top or bottom of 
					 * the Brick. */
				}
				break;
			}
		}

		double r, g, b;
		r = rand() / (double)RAND_MAX; // Produce a random float between 0 and 1
		g = rand() / (double)RAND_MAX;
		b = rand() / (double)RAND_MAX;
		int direct = GetRandomDirection(); // random ball direction
		// Create a new Circle object and push it to the world vector
		Circle B(x, y, radius, direct, 0.05, r, g, b);
		world.push_back(B); // push Circle to Vector
		// Make a maximum of 5 Circles bouncing around - erase the oldest ball if there are more than 5
		if (world.size() > 5) {
			world.erase(world.begin());
		}
	}
}


int GetRandomDirection() { // Moved function to be global
	return (rand() % 8) + 1;
}